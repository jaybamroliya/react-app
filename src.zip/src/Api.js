import React, { useEffect, useState } from 'react'

const Api = () => {
    const [data, setData] = useState([])

    useEffect(() => {
        fetchData()
    },[])

    const fetchData = async() =>{
        const result = await fetch("https://reqres.in/api/users?page=2")
        const result2 = await result.json()
        // console.log(result2.data);
        setData(result2.data)
    }


    return (
        <div className='container'>
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Email</th>
                        <th scope="col">FullName</th>
                        <th scope="col">Avatar</th>
                    </tr>
                </thead>
                <tbody>
                    {data && data.map((e) =>{
                        return(
                            <tr>
                            <th scope="row">{e.id}</th>
                            <td>{e.email}</td>
                            <td>{`${e.first_name} ${e.last_name}`}</td>
                            <td>
                                <img src={e.avatar} alt="" />
                            </td>
                        </tr>
                        )
                    })}
                   
                </tbody>
            </table>
        </div>
    )
}

export default Api
