import React from 'react'
import img2 from './img/about.jpg'

const MidSection = () => {
  return (
    <>
      <div className="container-fluid">
          <div className="row">
            <div className="col-md-6 position-relative">
              <div className="mid">
                <p>About Us</p>
                <h3>The best SEO solution with 10 years of experience</h3>
                <br />
                <p>Tempor erat elitr rebum at clita. Diam dolor diam ipsum et tempor sit. Aliqu diam amet diam et eos labore. Clita erat ipsum et lorem et sit, sed stet no labore lorem sit. Sanctus clita duo justo et tempor eirmod magna dolore erat amet</p>
              </div>
              <div className="div-1 d-flex">
                <div className="cd-1">
                <i class="fa fa-check" aria-hidden="true"></i> Award Winning
                </div>
                &nbsp;&nbsp;
                &nbsp;&nbsp;
                &nbsp;&nbsp;
                &nbsp;&nbsp;
                &nbsp;=&nbsp;
                <div className="cd-1">
                <i class="fa fa-check" aria-hidden="true"></i> 24/7 Support
                </div>
              </div>
              <div className="div-2 d-flex">
                <div className="cd-1">
                <i class="fa fa-check" aria-hidden="true"></i> Professional Staff
                </div>
                &nbsp;&nbsp;
                &nbsp;&nbsp;
                &nbsp;&nbsp;
                &nbsp;&nbsp;
                &nbsp;
                <div className="cd-1">
                <i class="fa fa-check" aria-hidden="true"></i> Fair Prices
                </div>
              </div>
              <div className="last-div d-flex">
                <div className="batn">
                <button className='read_btn'>Read More</button>
                </div>
                <div className="icons">
                  <i className='fa fa-instagram'></i>
                  <i className='fa fa-facebook'></i>
                  <i class="fa fa-twitter" aria-hidden="true"></i>
                  <i class="fa fa-linkedin-square" aria-hidden="true"></i>
                </div>
              </div>
            </div>
            <div className="col-md-6 image">
              <img src={img2} alt="" />
            </div>
          </div>
        </div>

    </>
  )
}

export default MidSection
