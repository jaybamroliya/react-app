import React, { useState } from 'react'
import img from './img/hero.png'

const HeroSection = () => {
  const [text,setText] = useState("All in one SEO tool need to grow your business rapidly")
  const [text2,setText2] = useState("Tempor rebum no at dolore lorem clita rebum rebum ipsum rebum stet dolor sed justo kasd. Ut dolor sed magna dolor sea diam. Sit diam sit justo amet ipsum vero ipsum clita lorem")
  
  const HandleQuotesbtn = () =>{
    setText("Soulmate")
    setText2("Do what makes your soul happy")
  }

  const HandleContectbtn = () =>{
    setText("About over contects")
    setText2(`There are some contects details , who makes our "SEO Master" tp the  Top `)
  }
  return (
    <div>
      <div className="container-fluid bg-primary">
          <div className="row p-5">
            <div className="col-md-6 position-relative">
              <div className="main">
                <h2>{text}</h2>
                <p className='text_pt'>{text2}</p>
              </div>
              <div className="btn-div">
                <button className='btn_one' onClick={HandleQuotesbtn}>Free Quote</button>
                <button className='btn_two' onClick={HandleContectbtn}>ContactUs</button>
              </div>
            </div>
            <div className="col-md-6 image">
              <img src={img} alt="" />
            </div>
          </div>
        </div>
    </div>
  )
}

export default HeroSection
