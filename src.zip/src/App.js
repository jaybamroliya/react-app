import React from 'react'
import './App.css'
import Navbar from './Navbar'
import HeroSection from './HeroSection'
import MidSection from './MidSection'
import Api from './Api'

const App = () => {
  return (
    <>
      <div className="header">
        <Navbar title="SEO" />
        {/* Hero section */}
        <HeroSection />
      </div>
      <MidSection />
      <Api/>

    </>
  )
}

export default App
